"use server";
import { revalidatePath } from "next/cache";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";
import { callPricingApi } from "@/lib/pricingApi";

const text=(f:FormData,k:string)=>String(f.get(k)??"").trim();
const num=(f:FormData,k:string,d:number)=>{const x=Number(text(f,k).replace(",","."));return Number.isFinite(x)?x:d};
const optional=(f:FormData,k:string)=>text(f,k)?num(f,k,0):null;
const json=(f:FormData,k:string)=>{try{return JSON.parse(text(f,k))}catch{throw new Error("Courbe de prix invalide.")}};
const path=(pid:string)=>`/admin/pricing?property=${encodeURIComponent(pid)}`;

export async function saveAndRecalculateAdminPricing(f:FormData){
 const pid=text(f,"property_id"),db=getSupabaseAdmin();
 const payload={property_id:pid,enabled:f.get("enabled")==="on",mode:"shadow",default_price:num(f,"default_price",100),default_weekend_price:optional(f,"default_weekend_price"),floor_price:num(f,"floor_price",50),ceiling_price:optional(f,"ceiling_price"),default_min_stay:Math.max(1,Math.trunc(num(f,"default_min_stay",2))),one_night_gap_multiplier:Math.max(1,num(f,"one_night_gap_multiplier",1.5)),one_night_release_days:Math.max(0,Math.trunc(num(f,"one_night_release_days",21))),protect_weekends:f.get("protect_weekends")==="on",planning_horizon_days:Math.max(30,Math.trunc(num(f,"planning_horizon_days",540))),optimisation_curve:json(f,"optimisation_curve"),optimisation_preset:text(f,"optimisation_preset")||"progressive",optimisation_horizon_days:Math.max(7,Math.trunc(num(f,"optimisation_horizon_days",120))),optimisation_max_discount_pct:Math.max(0,Math.min(80,num(f,"optimisation_max_discount_pct",30))),market_signal_enabled:f.get("market_signal_enabled")==="on",market_signal_influence_pct:Math.max(0,Math.min(100,num(f,"market_signal_influence_pct",0))),updated_at:new Date().toISOString()};
 const {error}=await db.from("pricing_property_settings").upsert(payload,{onConflict:"property_id"});if(error)throw new Error(error.message);
 await callPricingApi("/internal/pricing/regenerate",{property_id:pid,created_by:"admin",change_summary:text(f,"change_summary")||"Paramètres enregistrés"});revalidatePath(path(pid));
}

export async function saveAdminSeason(f:FormData){
 const pid=text(f,"property_id"),db=getSupabaseAdmin(),id=text(f,"id"),mode=text(f,"season_optimisation_mode")||"inherit";
 const payload={property_id:pid,name:text(f,"name"),start_date:text(f,"start_date"),end_date:text(f,"end_date"),weekday_price:num(f,"weekday_price",100),weekend_price:optional(f,"weekend_price"),floor_price:optional(f,"floor_price"),ceiling_price:optional(f,"ceiling_price"),min_stay:Math.max(1,Math.trunc(num(f,"min_stay",2))),priority:Math.trunc(num(f,"priority",100)),optimisation_mode:mode,optimisation_curve:mode==="custom"?json(f,"season_optimisation_curve"):null,optimisation_preset:mode==="custom"?(text(f,"season_optimisation_preset")||"progressive"):null,optimisation_horizon_days:mode==="custom"?Math.max(7,Math.trunc(num(f,"season_optimisation_horizon_days",120))):null,optimisation_max_discount_pct:mode==="custom"?Math.max(0,Math.min(80,num(f,"season_optimisation_max_discount_pct",20))):null,protect_from_automatic_reductions:mode==="none",market_signal_influence_pct:optional(f,"market_signal_influence_pct"),active:true,updated_at:new Date().toISOString()};
 const query=id?db.from("pricing_seasons").update(payload).eq("id",id).eq("property_id",pid):db.from("pricing_seasons").insert(payload);const {error}=await query;if(error)throw new Error(error.message);
 await callPricingApi("/internal/pricing/regenerate",{property_id:pid,created_by:"admin",change_summary:`Saison ${payload.name} ${id?"modifiée":"ajoutée"}`});revalidatePath(path(pid));
}
export async function deleteAdminSeason(f:FormData){const pid=text(f,"property_id"),db=getSupabaseAdmin();const {error}=await db.from("pricing_seasons").update({active:false,updated_at:new Date().toISOString()}).eq("id",text(f,"id")).eq("property_id",pid);if(error)throw new Error(error.message);await callPricingApi("/internal/pricing/regenerate",{property_id:pid,created_by:"admin",change_summary:"Saison retirée"});revalidatePath(path(pid));}
export async function rollbackAdminPricing(f:FormData){const pid=text(f,"property_id");await callPricingApi("/internal/pricing/rollback",{property_id:pid,target_version_id:text(f,"target_version_id"),created_by:"admin"});revalidatePath(path(pid));}
