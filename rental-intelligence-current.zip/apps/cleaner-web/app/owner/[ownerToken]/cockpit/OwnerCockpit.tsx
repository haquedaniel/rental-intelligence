"use client";


function calendarDayIsBookable(day: Record<string, any> | null | undefined): boolean {
  if (!day) return false;

  if ("bookable" in day) {
    const value = day.bookable;
    if (value === true || value === "true" || value === 1 || value === "1") return true;
    return false;
  }

  if ("units_available" in day || "unitsAvailable" in day) {
    const units = Number(day.units_available ?? day.unitsAvailable ?? 0);
    if (!Number.isFinite(units) || units <= 0) return false;
  }

  const status = String(day.status || "").toLowerCase();
  if (status && !["success_available", "available", "bookable", "open"].includes(status)) {
    return false;
  }

  return true;
}

function calendarDayPriceAmount(day: Record<string, any> | null | undefined): number | null {
  if (!day) return null;
  if (!calendarDayIsBookable(day)) return null;

  const nightlyFields = [
    "own_nightly_amount",
    "ownNightlyAmount",
    "nightly_amount",
    "nightly_price_eur",
    "available_price_eur",
    "public_price_eur",
    "recommended_price_eur",
    "daily_price_eur",
    "rate_eur",
    "price_eur",
  ];

  for (const field of nightlyFields) {
    const value = day[field];
    if (value === null || value === undefined || value === "") continue;
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed >= 25) return parsed;
  }

  const totalFields = [
    "own_total_amount",
    "ownTotalAmount",
    "total_amount",
    "offer_price",
  ];

  const nights = Number(day.nights || day.length_of_stay || day.stay_nights || 1);

  for (const field of totalFields) {
    const value = day[field];
    if (value === null || value === undefined || value === "") continue;
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) continue;

    const nightly = Number.isFinite(nights) && nights > 0 ? parsed / nights : parsed;
    if (nightly >= 25) return nightly;
  }

  return null;
}

function calendarDayPriceLabel(day: Record<string, any> | null | undefined): string | null {
  const amount = calendarDayPriceAmount(day);
  if (!amount) return null;

  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(amount);
}

function isCalendarDayBooked(day: Record<string, any> | null | undefined): boolean {
  if (!day) return false;

  return Boolean(
    day.reservation_id ||
    day.booking_id ||
    day.source_booking_id ||
    day.is_booked ||
    day.booked ||
    day.occupied ||
    day.status === "booked" ||
    day.status === "occupied",
  );
}

import { useEffect, useMemo, useState, type ReactNode, useRef } from "react";
import type {
  DailyPrice,
  MetricId,
  OwnerCockpitData,
  OwnerCockpitListing,
  PlanningMarker,
  PlanningReservation,
  Tone,
  TimelineEvent,
} from "./types";
import { usePathname } from "next/navigation";
import { OwnerJournalHeadlines, OwnerPricingCalendar } from "./OwnerPricingCalendar";

const MONTH_TARGET_FALLBACK = 4000;
const PLANNING_DAY_GAP_PX = 4; // Tailwind gap-1 between day cells.

function formatMoney(value: number, digits = 0) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(value || 0);
}

function toneSoft(tone: Tone) {
  const classes: Record<Tone, string> = {
    navy: "bg-[#112532]/6 text-[#112532] ring-[#112532]/10",
    blue: "bg-[#80A5B7]/16 text-[#315b6f] ring-[#80A5B7]/25",
    orange: "bg-[#E0680E]/12 text-[#B6520A] ring-[#E0680E]/18",
    mustard: "bg-[#F4B044]/18 text-[#8F6208] ring-[#F4B044]/28",
    green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  };
  return classes[tone];
}

function toneSolid(tone: Tone) {
  const classes: Record<Tone, string> = {
    navy: "bg-[#112532]",
    blue: "bg-[#80A5B7]",
    orange: "bg-[#E0680E]",
    mustard: "bg-[#F4B044]",
    green: "bg-emerald-500",
  };
  return classes[tone];
}

function tensionColor(value: number) {
  if (value > 0.72) return "bg-[#E0680E]";
  if (value > 0.52) return "bg-[#F4B044]";
  return "bg-[#80A5B7]";
}

function listingById(listings: OwnerCockpitListing[], id: string) {
  return listings.find((listing) => listing.id === id);
}


function InitialsAvatar({
  image,
  initials,
  tone = "blue",
  title,
  size = "h-8 w-8",
}: {
  image?: string | null;
  initials?: string;
  tone?: Tone;
  title?: string;
  size?: string;
}) {
  return (
    <span
      title={title}
      className={`inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-white text-[10px] font-black text-[#112532] shadow-sm ring-3 ${statusRing(tone)} ${size}`}
    >
      {image ? <img src={image} alt="" className="h-full w-full object-cover" /> : initials || "?"}
    </span>
  );
}

function statusRing(tone: Tone) {
  const classes: Record<Tone, string> = {
    navy: "ring-[#112532]",
    blue: "ring-[#80A5B7]",
    orange: "ring-[#E0680E]",
    mustard: "ring-[#F4B044]",
    green: "ring-emerald-500",
  };
  return classes[tone];
}

function ShellCard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-[1.7rem] bg-white shadow-[0_10px_30px_rgba(17,37,50,0.06)] ring-1 ring-[#112532]/8 ${className}`}>{children}</section>;
}

function PilotysMark() {
  return (
    <div className="flex items-center gap-3">
      <img src="/pilotys-assets/logo-mark-p.svg" alt="Pilotys" className="h-12 w-12 rounded-[1.1rem] shadow-sm" />
      <span className="text-xl font-black tracking-[0.28em] text-[#112532]">PILOTYS</span>
    </div>
  );
}

function TopNav({ notificationCount }: { notificationCount: number }) {
  return (
    <header className="sticky top-0 z-50 border-b border-[#112532]/8 bg-white/92 backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <PilotysMark />
        <div className="flex items-center gap-2">
          <button className="relative flex h-12 w-12 items-center justify-center rounded-full bg-[#F4F8FA] text-[#112532] ring-1 ring-[#112532]/8">
            ◴
            {notificationCount > 0 ? (
              <span className="absolute -right-0.5 -top-1 flex h-6 min-w-6 items-center justify-center rounded-full bg-[#E0680E] px-1 text-xs font-black text-white">
                {Math.min(9, notificationCount)}
              </span>
            ) : null}
          </button>
          <button className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-2xl font-black text-[#112532] ring-1 ring-[#112532]/10">≡</button>
        </div>
      </div>
    </header>
  );
}


function LiveRealisedTicker({ financial }: { financial: OwnerCockpitData["financial"] }) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    if (!financial.activeDailyRevenue) return;

    const interval = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(interval);
  }, [financial.activeDailyRevenue]);

  if (!financial.activeDailyRevenue) {
    return <>{formatMoney(financial.realisedRevenue, 2)}</>;
  }

  const secondsElapsed =
    now.getHours() * 3600 +
    now.getMinutes() * 60 +
    now.getSeconds() +
    now.getMilliseconds() / 1000;

  const liveValue = Math.min(
    financial.realisedAtStartOfToday + financial.activeDailyRevenue,
    financial.realisedAtStartOfToday + (financial.activeDailyRevenue * secondsElapsed) / 86_400,
  );

  return <>{formatMoney(liveValue, 2)}</>;
}

function MoneyHero({ data }: { data: OwnerCockpitData }) {
  const [metric, setMetric] = useState<MetricId>("realised");

  const realised = data.financial.realisedRevenue;
  const gross = data.financial.grossAnnualRevenue;
  const net = data.financial.afterVariables;

  return (
    <section className="space-y-4">
      <button
        onClick={() => setMetric("realised")}
        className={`relative w-full overflow-hidden rounded-[1.8rem] bg-white p-5 text-left shadow-[0_12px_32px_rgba(17,37,50,0.06)] ring-1 transition sm:p-6 ${
          metric === "realised" ? "ring-[#E0680E]/35" : "ring-[#112532]/8"
        }`}
      >
        <img src="/pilotys-assets/pattern-routes.svg" alt="" className="absolute right-0 top-0 hidden h-full w-72 opacity-70 sm:block" />
        <div className="relative">
          <p className="text-sm font-black uppercase tracking-[0.17em] text-[#E0680E]">CA réalisé</p>
          <p className="mt-2 text-6xl font-black tracking-tight text-[#112532] sm:text-7xl">
            <LiveRealisedTicker financial={data.financial} />
          </p>
          {data.financial.activeDailyRevenue > 0 && (
            <p className="mt-2 text-xs font-bold text-[#112532]/55">
              Live · {formatMoney(data.financial.activeDailyRevenue)} / jour en cours
            </p>
          )}
        </div>
      </button>

      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        <MetricButton active={metric === "gross"} onClick={() => setMetric("gross")} label="CA brut annuel" value={formatMoney(gross)} delta={data.financial.grossDeltaPct} tone="blue" />
        <MetricButton active={metric === "net"} onClick={() => setMetric("net")} label="Après variables" value={formatMoney(net)} delta={data.financial.afterVariablesDeltaPct} tone="mustard" />
      </div>

      <MetricPanel data={data} metric={metric} />
    </section>
  );
}

function MetricButton({ active, onClick, label, value, delta, tone }: { active: boolean; onClick: () => void; label: string; value: string; delta?: number | null; tone: Tone }) {
  const wave = tone === "mustard" ? "#F4B044" : "#80A5B7";
  const icon = tone === "mustard" ? "€" : "▮▮▮";

  return (
    <button
      onClick={onClick}
      className={`relative min-h-[11.5rem] overflow-hidden rounded-[1.6rem] bg-white p-4 text-left shadow-[0_10px_28px_rgba(17,37,50,0.05)] ring-1 transition sm:min-h-[12rem] sm:p-5 ${
        active ? "ring-[#E0680E]/36 shadow-[0_14px_34px_rgba(224,104,14,0.09)]" : "ring-[#112532]/8 hover:ring-[#112532]/15"
      }`}
    >
      <svg viewBox="0 0 320 90" preserveAspectRatio="none" className="absolute inset-x-0 bottom-0 h-14 w-full opacity-25">
        <path d="M0 48 C58 82 104 38 164 55 C222 72 262 25 320 45 V90 H0 Z" fill={wave} />
      </svg>
      <div className="relative flex items-center gap-3">
        <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-black ring-1 sm:h-12 sm:w-12 ${toneSoft(tone)}`}>{icon}</span>
        <span className="text-[0.7rem] font-black uppercase leading-4 tracking-[0.05em] text-[#112532] sm:text-sm">{label}</span>
      </div>
      <p className="relative mt-6 text-3xl font-black tracking-tight text-[#112532] sm:text-4xl">{value}</p>
      {typeof delta === "number" ? <p className="relative mt-5 text-sm font-black text-emerald-500">vs N-1 · ↑ {Math.round(delta)} %</p> : null}
    </button>
  );
}

function MetricPanel({ data, metric }: { data: OwnerCockpitData; metric: MetricId }) {
  if (metric === "gross") {
    const total = Math.max(1, data.listings.reduce((sum, listing) => sum + listing.revenue, 0));

    return (
      <ShellCard className="overflow-hidden p-5 sm:p-6">
        <h2 className="text-3xl font-black tracking-tight text-[#112532]">CA brut par logement</h2>
        <div className="mt-5 space-y-4">
          {data.listings.map((listing) => (
            <div key={listing.id} className="grid grid-cols-[8rem_1fr_5.5rem] items-center gap-3 text-sm font-black sm:grid-cols-[12rem_1fr_7rem]">
              <span className="truncate text-[#112532]/70">{listing.name}</span>
              <div className="h-4 overflow-hidden rounded-full bg-[#F4F8FA] ring-1 ring-[#112532]/6">
                <div className="h-full rounded-full" style={{ width: `${Math.max(8, (listing.revenue / total) * 100)}%`, backgroundColor: listing.dot }} />
              </div>
              <span className="text-right text-[#112532]">{formatMoney(listing.revenue)}</span>
            </div>
          ))}
        </div>
      </ShellCard>
    );
  }

  if (metric === "net") {
    const gross = data.financial.grossAnnualRevenue;
    const net = data.financial.afterVariables;
    const variableCosts = data.financial.variableCosts ?? Math.max(0, gross - net);
    const expenseItems = data.financial.expenseBreakdownItems ?? [];

    const netPct = gross ? Math.max(0, Math.min(100, (net / gross) * 100)) : 0;
    const costPct = gross ? Math.max(0, Math.min(100, (variableCosts / gross) * 100)) : 0;
    const rows = [
      { label: "CA brut", value: gross, left: 0, width: 100, tone: "blue" as Tone, sign: "" },
      { label: "Coûts variables", value: variableCosts, left: netPct, width: costPct, tone: "mustard" as Tone, sign: "-" },
      { label: "Après variables", value: net, left: 0, width: netPct, tone: "orange" as Tone, sign: "" },
    ];

    return (
      <ShellCard className="overflow-hidden p-5 sm:p-6">
        <h2 className="text-3xl font-black tracking-tight text-[#112532]">Après variables</h2>
        <div className="mt-5 space-y-4">
          {rows.map((row) => (
            <div key={row.label} className="grid grid-cols-[8rem_1fr_5.5rem] items-center gap-3 text-sm font-black sm:grid-cols-[12rem_1fr_7rem]">
              <span className="truncate text-[#112532]/70">{row.label}</span>
              <div className="relative h-4 overflow-hidden rounded-full bg-[#F4F8FA] ring-1 ring-[#112532]/6">
                <div
                  className={`absolute top-0 h-full rounded-full ${toneSolid(row.tone)}`}
                  style={{ left: `${row.left}%`, width: `${Math.max(4, row.width)}%` }}
                />
              </div>
              <span className="text-right text-[#112532]">{row.sign}{formatMoney(row.value)}</span>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-[1.35rem] bg-[#F4F8FA] p-4 ring-1 ring-[#112532]/6">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-black uppercase tracking-[0.12em] text-[#80A5B7]">Détail des coûts variables</p>
            <p className="text-sm font-black text-[#112532]">{formatMoney(variableCosts)}</p>
          </div>

          {expenseItems.length === 0 ? (
            <p className="mt-3 text-sm font-bold text-[#112532]/55">
              Aucun détail de ligne détecté. Si le total existe, il vient probablement de lignes mensuelles sans catégorie reconnue.
            </p>
          ) : (
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {expenseItems.map((item) => {
                const pct = variableCosts ? Math.round((item.amount / variableCosts) * 100) : 0;
                return (
                  <div key={item.label} className="rounded-2xl bg-white p-3 ring-1 ring-[#112532]/6">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-black text-[#112532]">{item.label}</p>
                        <p className="mt-0.5 text-[11px] font-bold text-[#112532]/45">{item.count} ligne{item.count > 1 ? "s" : ""} · {pct}% des coûts</p>
                      </div>
                      <p className="shrink-0 text-sm font-black text-[#112532]">{formatMoney(item.amount)}</p>
                    </div>
                    <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-[#F4F8FA] ring-1 ring-[#112532]/6">
                      <div className="h-full rounded-full bg-[#F4B044]" style={{ width: `${Math.max(4, pct)}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </ShellCard>
    );
  }

  return <MonthlyRevenueChart data={data} />;
}

function MonthlyRevenueChart({ data }: { data: OwnerCockpitData }) {
  const max = Math.max(1, ...data.monthlyRevenue.map((row) => row.realised + row.future, MONTH_TARGET_FALLBACK));
  return (
    <ShellCard className="overflow-hidden p-5 sm:p-6">
      <h2 className="text-3xl font-black tracking-tight text-[#112532]">Revenus mensuels</h2>
      <div className="mt-5 flex flex-wrap gap-4 text-sm font-black text-[#112532]/65">
        <span className="inline-flex items-center gap-2"><span className="h-3 w-7 rounded-full bg-[#E0680E]" />Réalisé</span>
        <span className="inline-flex items-center gap-2"><span className="h-3 w-7 rounded-full bg-[#80A5B7]" />À venir</span>
        <span className="inline-flex items-center gap-2"><span className="h-0.5 w-7 border-t-2 border-dashed border-[#F4B044]" />Objectif</span>
      </div>
      <div className="relative mt-5">
        <div className="absolute left-0 right-0 top-[43%] border-t-2 border-dashed border-[#F4B044]" />
        <div className="grid grid-cols-12 items-end gap-1.5 sm:gap-3">
          {data.monthlyRevenue.map((row) => {
            const total = row.realised + row.future;
            const totalHeight = Math.max(28, (total / max) * 184);
            const realisedPct = total ? (row.realised / total) * 100 : 0;
            const futurePct = total ? (row.future / total) * 100 : 0;
            return (
              <div key={row.month} className="relative flex min-w-0 flex-col items-center gap-3">
                <div className="relative flex h-[196px] w-full items-end justify-center">
                  <div className={`flex w-full max-w-[2.05rem] flex-col-reverse overflow-hidden rounded-t-[1rem] shadow-sm ${row.live ? "ring-2 ring-[#E0680E]/25" : ""}`} style={{ height: `${totalHeight}px` }}>
                    {row.realised > 0 ? <div className="w-full bg-[#E0680E]" style={{ height: `${realisedPct}%` }} /> : null}
                    {row.future > 0 ? <div className="w-full bg-[#80A5B7]" style={{ height: `${futurePct}%` }} /> : null}
                  </div>
                </div>
                <span className="text-[0.65rem] font-black uppercase tracking-[-0.02em] text-[#477084] sm:text-xs">{row.month}</span>
              </div>
            );
          })}
        </div>
      </div>
    </ShellCard>
  );
}


function ActionMessage({ data }: { data: OwnerCockpitData }) {
  const actionEvent =
    data.timelineEvents.find(
      (event) =>
        event.tone === "orange" &&
        (event.kind === "cleaning" || event.kind === "intervention"),
    ) ||
    data.timelineEvents.find((event) => event.title.toLowerCase().includes("paiement"));

  if (!actionEvent) {
    return <>Tout est à jour.</>;
  }

  const label =
    actionEvent.kind === "cleaning"
      ? "Ménage"
      : actionEvent.kind === "intervention"
        ? "Intervention"
        : actionEvent.kind === "arrival"
          ? "Arrivée"
          : actionEvent.kind === "departure"
            ? "Départ"
            : "Action";

  return (
    <>
      {label}
      {actionEvent.status ? <span className="text-[#E0680E]"> · {actionEvent.status}</span> : null}
      <span className="text-[#112532]/70"> — {actionEvent.detail}</span>
    </>
  );
}

function SmartBrief({ data }: { data: OwnerCockpitData }) {
  return (
    <ShellCard className="overflow-hidden p-5 sm:p-6">
      <div className="flex items-start gap-4">
        <span className="mt-1 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#FFF6EF] text-xl text-[#E0680E] ring-1 ring-[#E0680E]/14">✦</span>
        <div className="min-w-0">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#80A5B7]">À retenir</p>
          <p className="mt-2 text-xl font-black leading-8 text-[#112532] sm:text-2xl">
            <ActionMessage data={data} />
          </p>
        </div>
      </div>
    </ShellCard>
  );
}

function PropertySelector({ data, selected, setSelected }: { data: OwnerCockpitData; selected: string[]; setSelected: (next: string[]) => void }) {
  function toggle(id: string) {
    if (selected.includes(id)) {
      if (selected.length > 1) setSelected(selected.filter((item) => item !== id));
      return;
    }
    setSelected([...selected, id]);
  }

  return (
    <section className="space-y-3">
      <div>
        <p className="text-xs font-black uppercase tracking-[0.18em] text-[#E0680E]">Opérations</p>
        <h2 className="mt-1 text-3xl font-black tracking-tight text-[#112532]">Réservations, ménages et interventions</h2>
      </div>

      <div className="-mx-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
        <div className="grid auto-cols-[minmax(17rem,1fr)] grid-flow-col gap-3 lg:grid-flow-row lg:grid-cols-4">
          {data.listings.map((listing) => {
            const active = selected.includes(listing.id);
            return (
              <button
                key={listing.id}
                onClick={() => toggle(listing.id)}
                className={`flex h-24 w-full min-w-[17rem] items-center gap-3 rounded-[1.35rem] bg-white p-2 pr-4 text-left shadow-[0_8px_24px_rgba(17,37,50,0.05)] ring-1 transition ${
                  active ? "ring-[#E0680E]/35" : "opacity-55 ring-[#112532]/8"
                }`}
              >
                <div className="relative h-20 w-24 shrink-0 overflow-hidden rounded-2xl bg-[#F4F8FA]">
                  {listing.image ? (
                    <img src={listing.image} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="flex h-full w-full items-center justify-center text-xl font-black text-[#112532]/45">{listing.short}</span>
                  )}
                  <span className="absolute left-2 top-2 h-3 w-3 rounded-full ring-2 ring-white" style={{ backgroundColor: listing.dot }} />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-black text-[#112532]">{listing.name}</p>
                  <p className="mt-1 text-xs font-bold text-[#112532]/50">{listing.occupancy}% · {formatMoney(listing.revenue)}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-[1.25rem] bg-white/65 px-3 py-2 text-xs font-black text-[#112532]/55 ring-1 ring-[#112532]/6">
        <span className="mr-1 uppercase tracking-[0.14em] text-[#80A5B7]">Légende planning</span>
        {data.listings.map((listing) => (
          <span key={`legend-${listing.id}`} className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 ring-1 ring-[#112532]/6">
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: listing.dot }} />
            <span className="max-w-[10rem] truncate">{listing.name}</span>
          </span>
        ))}
        <span className="mx-1 h-5 w-px bg-[#112532]/10" />
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 ring-1 ring-[#112532]/6"><span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />Confirmé</span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 ring-1 ring-[#112532]/6"><span className="h-2.5 w-2.5 rounded-full bg-[#F4B044]" />Proposé</span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 ring-1 ring-[#112532]/6"><span className="h-2.5 w-2.5 rounded-full bg-[#E0680E]" />Action</span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 ring-1 ring-[#112532]/6"><span className="h-2.5 w-2.5 rounded-full bg-[#80A5B7]" />Terminé</span>
      </div>
    </section>
  );
}


function AutoScrollPlanningRail({
  children,
  dayWidthPx,
  todayOffset,
}: {
  children: React.ReactNode;
  dayWidthPx: number;
  todayOffset: number;
}) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const rail = ref.current;
    if (!rail) return;

    const targetLeft = Math.max(0, todayOffset * dayWidthPx - rail.clientWidth * 0.35);
    rail.scrollTo({ left: targetLeft, behavior: "instant" as ScrollBehavior });
  }, [dayWidthPx, todayOffset]);

  return (
    <div ref={ref} className="w-full overflow-x-auto bg-white">
      {children}
    </div>
  );
}




function planningDayPitchPx(dayWidthPx: number) {
  return dayWidthPx + PLANNING_DAY_GAP_PX;
}

function dayCenterLeftPx(day: number, dayWidthPx: number) {
  const pitch = planningDayPitchPx(dayWidthPx);
  return (Math.max(1, day) - 1) * pitch + dayWidthPx / 2;
}

function reservationLeftPx(reservation: PlanningReservation, dayWidthPx: number) {
  // Check-in afternoon: start halfway through the check-in day.
  return dayCenterLeftPx(reservation.start, dayWidthPx);
}

function reservationWidthPx(reservation: PlanningReservation, dayWidthPx: number) {
  // Checkout morning: end halfway through the checkout day.
  // A stay with span N should run from the centre of day D to the centre of day D+N.
  return Math.max(44, reservation.span * planningDayPitchPx(dayWidthPx));
}

function reservationCleaningBorder(state: PlanningReservation["cleaningState"]) {
  if (state === "accepted") return "ring-2 ring-emerald-500/90";
  if (state === "planned") return "ring-2 ring-[#F4B044]/90";
  return "ring-2 ring-[#E05243]/90";
}

function reservationCleaningLine(state: PlanningReservation["cleaningState"]) {
  if (state === "accepted") return "bg-emerald-500";
  if (state === "planned") return "bg-[#F4B044]";
  return "bg-[#E05243]";
}

function reservationCleaningTitle(state: PlanningReservation["cleaningState"]) {
  if (state === "accepted") return "Ménage accepté";
  if (state === "planned") return "Ménage prévu, à confirmer";
  return "Aucune mission de ménage planifiée";
}


function ReservationTooltip({ reservation }: { reservation: PlanningReservation }) {
  return (
    <span className="absolute left-1/2 top-full z-[80] mt-2 hidden w-64 -translate-x-1/2 rounded-2xl bg-white p-3 text-left text-[#112532] shadow-[0_18px_48px_rgba(17,37,50,0.22)] ring-1 ring-[#112532]/10 group-hover:block">
      <span className="block truncate text-sm font-black">{reservation.guest}</span>
      <span className="mt-1 block text-xs font-bold text-[#112532]/58">
        {formatMoney(reservation.price)} · {reservation.span} nuit{reservation.span > 1 ? "s" : ""} · {reservation.nightly}€/nuit
      </span>
      <span className="mt-2 inline-flex rounded-full bg-[#F4F8FA] px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#112532]/55">
        {reservationCleaningTitle(reservation.cleaningState)}
      </span>
    </span>
  );
}

function MissionGroupPopover({ markers }: { markers: PlanningMarker[] }) {
  const [open, setOpen] = useState(false);
  const first = markers[0];

  if (markers.length === 1) {
    return (
      <a href={first.href} title={`${first.label} · ${first.statusLabel}`} className="relative transition hover:scale-105">
        <InitialsAvatar
          image={first.avatarUrl}
          initials={first.avatarInitials}
          tone={first.tone}
          title={`${first.label} · ${first.statusLabel}`}
          size="h-7 w-7"
        />
      </a>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        title={`${markers.length} missions`}
        className={`flex h-7 min-w-7 items-center justify-center rounded-full px-2 text-[10px] font-black text-white shadow-sm ring-3 ${statusRing(first.tone)} ${toneSolid(first.tone)} transition hover:scale-105`}
      >
        {markers.length}
      </button>

      {open ? (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#112532]/24 px-4 py-6"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-[1.5rem] bg-white p-3 text-left shadow-[0_24px_80px_rgba(17,37,50,0.32)] ring-1 ring-[#112532]/10"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-2 flex items-center justify-between px-2 py-1">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.16em] text-[#80A5B7]">Choisir une mission</p>
                <p className="mt-1 text-sm font-black text-[#112532]">{markers.length} missions ce jour</p>
              </div>
              <button type="button" onClick={() => setOpen(false)} className="rounded-full px-3 py-2 text-sm font-black text-[#112532]/45 hover:bg-[#F4F8FA]">×</button>
            </div>

            <div className="max-h-[60vh] space-y-1 overflow-y-auto pr-1">
              {markers.map((marker) => (
                <a
                  key={marker.id}
                  href={marker.href}
                  className="flex items-center gap-3 rounded-2xl px-3 py-3 text-[#112532] hover:bg-[#F4F8FA]"
                >
                  <InitialsAvatar
                    image={marker.avatarUrl}
                    initials={marker.avatarInitials}
                    tone={marker.tone}
                    title={`${marker.label} · ${marker.statusLabel}`}
                    size="h-9 w-9"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-black text-[#112532]">{marker.label}</span>
                    <span className="mt-0.5 block truncate text-xs font-bold text-[#112532]/50">{marker.statusLabel}</span>
                  </span>
                  <span className="text-sm font-black text-[#E0680E]">→</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

function Planning({ data, selected }: { data: OwnerCockpitData; selected: string[] }) {
  const selectedListings = data.listings.filter((listing) => selected.includes(listing.id));
  const dayWidthPx = 76;
  const dayWidth = `${dayWidthPx}px`;
  const todayOffset = Math.max(0, data.planningDays.findIndex((day) => day.key === data.today));
  const gridTemplateColumns = `repeat(${data.planningDays.length}, ${dayWidth})`;

  const reservationsByListing = useMemo(() => {
    const map = new Map<string, PlanningReservation[]>();
    for (const listing of data.listings) map.set(listing.id, []);
    for (const reservation of data.planningReservations) {
      const list = map.get(reservation.listingId) ?? [];
      list.push(reservation);
      map.set(reservation.listingId, list);
    }
    for (const list of map.values()) list.sort((a, b) => a.start - b.start);
    return map;
  }, [data.listings, data.planningReservations]);

  const coveredDaysByListing = useMemo(() => {
    const covered = new Map<string, Set<number>>();
    for (const listing of data.listings) covered.set(listing.id, new Set<number>());
    for (const reservation of data.planningReservations) {
      const set = covered.get(reservation.listingId);
      if (!set) continue;
      for (let day = reservation.start; day < reservation.start + reservation.span; day++) set.add(day);
    }
    return covered;
  }, [data.listings, data.planningReservations]);

  const dailyPriceByKey = useMemo(() => {
    const map = new Map<string, DailyPrice>();
    for (const price of data.dailyPrices) map.set(`${price.listingId}:${price.day}`, price);
    return map;
  }, [data.dailyPrices]);

  const markerGroups = useMemo(() => {
    const map = new Map<string, PlanningMarker[]>();
    for (const marker of data.planningMarkers) {
      const key = `${marker.listingId}:${marker.day}`;
      const list = map.get(key) ?? [];
      list.push(marker);
      map.set(key, list);
    }
    return map;
  }, [data.planningMarkers]);

  return (
    <ShellCard className="overflow-hidden">
      <AutoScrollPlanningRail dayWidthPx={dayWidthPx} todayOffset={todayOffset}>
        <div className="min-w-max p-3">
          <div className="space-y-2">
            <div className="grid gap-1" style={{ gridTemplateColumns }}>
              {data.monthSpans.map((span) => (
                <div key={`${span.month}-${span.start}`} className="rounded-2xl bg-[#F4F8FA] px-4 py-2 text-sm font-black text-[#477084]" style={{ gridColumn: `${span.start} / span ${span.span}` }}>
                  {span.month}
                </div>
              ))}
            </div>

            <div className="grid gap-1" style={{ gridTemplateColumns }}>
              {data.planningDays.map((day) => (
                <div key={day.key} className="whitespace-pre-line rounded-2xl bg-[#F4F8FA] px-2 py-2 text-center text-[11px] font-black leading-4 text-[#112532]/60 ring-1 ring-[#112532]/5">
                  {day.label}
                </div>
              ))}
            </div>

            <div className="grid gap-1" style={{ gridTemplateColumns }}>
              {data.planningDays.map((day) => (
                <div key={`tension-${day.key}`} className={`h-3 rounded-full ${tensionColor(day.tension)}`} style={{ opacity: 0.18 + day.tension * 0.38 }} />
              ))}
            </div>
          </div>

          <div className="mt-3 space-y-3">
            {selectedListings.map((listing) => {
              const rowReservations = reservationsByListing.get(listing.id) ?? [];
              const coveredDays = coveredDaysByListing.get(listing.id) ?? new Set<number>();

              return (
                <div key={listing.id} className="relative">
                  <div className="h-[5.6rem] rounded-[1.35rem] bg-[#F4F8FA]/72 p-2 ring-1 ring-[#112532]/5">
                    <div className="relative h-full overflow-hidden rounded-[1rem]">
                      <div className="absolute bottom-2 left-2 top-2 z-40 w-1 rounded-full ring-1 ring-white/70" style={{ backgroundColor: listing.dot }} title={listing.name} />

                      <div className="absolute inset-0 grid gap-1" style={{ gridTemplateColumns }}>
                        {data.planningDays.map((_, index) => {
                          const day = index + 1;
                          const covered = coveredDays.has(day);
                          const price = dailyPriceByKey.get(`${listing.id}:${day}`);
                          return (
                            <div key={`${listing.id}-cell-${day}`} className="relative rounded-xl bg-white/88 ring-1 ring-white/70">
                              {!covered && price && calendarDayPriceLabel(price) ? (
                                <div
                                  title="Prix jour libre"
                                  className="pointer-events-none absolute bottom-1 left-1/2 -translate-x-1/2 rounded-full bg-white/70 px-1.5 py-0.5 text-[9px] font-black text-[#112532]/38 ring-1 ring-[#112532]/5"
                                >
                                  {calendarDayPriceLabel(price)}
                                </div>
                              ) : null}
                            </div>
                          );
                        })}
                      </div>

                      <div className="absolute inset-x-0 top-1/2 z-10 h-px -translate-y-1/2">
                        {rowReservations
                          .filter((reservation) => reservation.cleaningDay)
                          .map((reservation) => {
                            const startPx = reservationLeftPx(reservation, dayWidthPx);
                            const endPx = dayCenterLeftPx(reservation.cleaningDay ?? reservation.start, dayWidthPx);
                            const left = Math.min(startPx, endPx);
                            const width = Math.max(12, Math.abs(endPx - startPx));
                            return (
                              <div
                                key={`${reservation.id}-cleaning-link`}
                                className={`absolute top-0 h-0.5 rounded-full opacity-65 ${reservationCleaningLine(reservation.cleaningState)}`}
                                style={{ left, width }}
                                title={reservationCleaningTitle(reservation.cleaningState)}
                              />
                            );
                          })}
                      </div>

                      <div className="absolute inset-0 z-20 pointer-events-auto">
                        {rowReservations.map((reservation) => (
                          <a
                            key={reservation.id}
                            href={reservation.href}
                            className={`group absolute top-1/2 block h-[2.75rem] -translate-y-1/2 overflow-visible rounded-2xl px-3 py-1 text-center text-white shadow-[0_6px_18px_rgba(17,37,50,0.10)] transition hover:translate-y-[-55%] hover:shadow-[0_10px_28px_rgba(17,37,50,0.18)] ${reservationCleaningBorder(reservation.cleaningState)}`}
                            style={{
                              left: reservationLeftPx(reservation, dayWidthPx),
                              width: reservationWidthPx(reservation, dayWidthPx),
                              backgroundColor: listing.dot,
                            }}
                          >
                            <span className="absolute inset-0 overflow-hidden rounded-2xl">
                              <span className="absolute inset-x-0 top-0 h-1/2 bg-white/8" />
                            </span>
                            <span className="relative flex h-full items-center justify-center truncate px-3 text-xs font-black leading-5">{reservation.guest}</span>
                            <ReservationTooltip reservation={reservation} />
                          </a>
                        ))}
                      </div>

                      <div className="absolute inset-0 z-30 pointer-events-none">
                        {data.planningDays.map((_, index) => {
                          const day = index + 1;
                          const markers = markerGroups.get(`${listing.id}:${day}`) ?? [];
                          if (markers.length === 0) return null;
                          return (
                            <div
                              key={`${listing.id}-mission-${day}`}
                              className="pointer-events-auto absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
                              style={{ left: dayCenterLeftPx(day, dayWidthPx) }}
                            >
                              <MissionGroupPopover markers={markers} />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </AutoScrollPlanningRail>
    </ShellCard>
  );
}

function TimelineBrowser({ data }: { data: OwnerCockpitData }) {
  const past = data.timelineEvents.filter((event) => event.side === "past");
  const future = data.timelineEvents.filter((event) => event.side === "future");

  return (
    <ShellCard className="overflow-hidden p-5">
      <div>
        <p className="text-xs font-black uppercase tracking-[0.18em] text-[#80A5B7]">Activité</p>
        <h2 className="mt-1 text-3xl font-black tracking-tight text-[#112532]">Timeline</h2>
      </div>

      <div className="relative mt-5 max-h-[34rem] overflow-y-auto pr-1">
        <div className="absolute bottom-0 left-[1.18rem] top-0 w-0.5 rounded-full bg-[#D8E6EC]" />

        <div className="space-y-3 pb-4">
          {past.map((event) => <TimelineRow key={event.id} event={event} listings={data.listings} muted />)}
        </div>

        <div className="relative my-4 flex items-center gap-3">
          <span className="z-10 flex h-10 w-10 items-center justify-center rounded-full bg-[#112532] text-xs font-black text-white ring-4 ring-white">auj.</span>
          <div className="h-px flex-1 bg-[#112532]/12" />
          <span className="rounded-full bg-[#112532]/6 px-3 py-1 text-xs font-black uppercase tracking-[0.14em] text-[#112532]/55">Aujourd’hui</span>
        </div>

        <div className="space-y-3 pt-1">
          {future.map((event) => <TimelineRow key={event.id} event={event} listings={data.listings} />)}
        </div>
      </div>
    </ShellCard>
  );
}

function TimelineRow({ event, listings, muted = false }: { event: TimelineEvent; listings: OwnerCockpitListing[]; muted?: boolean }) {
  const listing = listingById(listings, event.listingId);
  const isMission = event.kind === "cleaning" || event.kind === "intervention";
  const avatarImage = isMission ? event.avatarUrl : listing?.image;
  const avatarInitials = isMission ? event.avatarInitials : listing?.short;
  const row = (
    <span className={`relative grid w-full grid-cols-[52px_1fr_auto] items-center gap-3 rounded-2xl px-2 py-2 text-left transition hover:bg-[#F4F8FA] ${muted ? "opacity-72" : ""}`}>
      <span className="absolute bottom-0 left-[1.58rem] top-0 w-0.5 bg-[#D8E6EC]" />
      <span className="relative z-10 flex items-center justify-center">
        <InitialsAvatar
          image={avatarImage}
          initials={avatarInitials}
          tone={event.tone}
          title={isMission ? event.detail : listing?.name}
          size="h-11 w-11"
        />
      </span>
      <span className="min-w-0">
        <span className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: listing?.dot ?? "#112532" }} />
          <span className="truncate text-base font-black text-[#112532]">{event.title}</span>
        </span>
        <span className="mt-0.5 block truncate text-sm font-bold text-[#112532]/55">{listing?.name ?? "Logement"} · {event.detail}</span>
      </span>
      <span className="flex shrink-0 flex-col items-end gap-1">
        <span className="text-xs font-bold text-[#112532]/50">{event.time}</span>
        {event.status ? <span className={`rounded-full px-2 py-1 text-[10px] font-black ring-1 ${toneSoft(event.tone)}`}>{event.status}</span> : null}
      </span>
    </span>
  );

  return event.href ? <a href={event.href} className="block">{row}</a> : <div>{row}</div>;
}

function Opportunities({ data }: { data: OwnerCockpitData }) {
  return (
    <ShellCard className="overflow-hidden p-5">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#80A5B7]">Opportunités</p>
          <h2 className="mt-1 text-3xl font-black tracking-tight text-[#112532]">À tester</h2>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.opportunities.map((item) => (
          <div key={item.id} className="rounded-[1.45rem] bg-white p-4 shadow-[0_8px_22px_rgba(17,37,50,0.04)] ring-1 ring-[#112532]/8">
            <div className="flex items-center gap-2">
              <span className={`flex h-9 w-9 items-center justify-center rounded-full ring-1 ${toneSoft(item.tone)}`}>↗</span>
              <p className="text-lg font-black text-[#112532]">{item.title}</p>
            </div>
            <p className="mt-3 text-sm font-black text-[#112532]">{item.listing}</p>
            <p className="mt-1 text-sm font-bold text-[#112532]/58">{item.period}</p>
            <div className="mt-4">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-[#112532]/45">Potentiel estimé</p>
              <p className="mt-1 text-3xl font-black tracking-tight text-[#E0680E]">{formatMoney(item.potential)}</p>
            </div>
            <button className={`mt-5 w-full rounded-full px-4 py-3 text-sm font-black ${item.tone === "orange" ? "bg-[#E0680E] text-white" : item.tone === "mustard" ? "border border-[#F4B044] bg-white text-[#D58908]" : "border border-[#80A5B7] bg-white text-[#477084]"}`}>
              {item.action}
            </button>
          </div>
        ))}
      </div>
    </ShellCard>
  );
}


function cockpitNavBase(pathname: string | null) {
  const path = pathname || "";
  const tokenMatch = path.match(/^\/owner\/([^/]+)\/cockpit/);
  if (tokenMatch?.[1]) return `/owner/${tokenMatch[1]}/cockpit`;
  return "/owner/cockpit";
}

function BottomNav() {
  const pathname = usePathname();
  const cockpit = cockpitNavBase(pathname);

  const items = [
    { label: "Cockpit", short: "Cockpit", icon: "✦", href: cockpit, active: true },
    { label: "Réservations", short: "Séjours", icon: "▦", href: `${cockpit}?view=planning` },
    { label: "Missions", short: "Missions", icon: "✓", href: `${cockpit}?view=alerts` },
    { label: "Paiements", short: "€", icon: "€", href: "/owner/payments" },
    { label: "Réglages", short: "Réglages", icon: "⚙", href: "/admin/settings" },
  ];

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-50 px-3 pb-3 xl:hidden">
      <nav className="pointer-events-auto relative mx-auto max-w-md overflow-hidden rounded-[1.7rem] bg-white/90 p-1.5 shadow-2xl shadow-[#112532]/18 ring-1 ring-[#112532]/10 backdrop-blur-xl">
        <div className="absolute inset-x-8 top-0 h-0.5 rounded-full bg-gradient-to-r from-[#E0680E] via-[#F4B044] to-[#80A5B7]" />

        <div className="grid grid-cols-5 gap-1">
          {items.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className={[
                "relative flex min-h-[3.55rem] flex-col items-center justify-center rounded-[1.25rem] px-1 text-center transition",
                item.active
                  ? "bg-[#112532] text-white shadow-lg shadow-[#112532]/18 ring-[#112532]/10"
                  : "bg-white/78 text-[#112532]/62 ring-[#112532]/8 hover:bg-white hover:text-[#112532]",
              ].join(" ")}
            >
              <span
                className={[
                  "grid h-6 w-6 place-items-center rounded-full text-[11px] font-black",
                  item.active ? "bg-white/16 text-white" : "bg-[#112532]/6 text-[#112532]/50",
                ].join(" ")}
              >
                {item.icon}
              </span>
              <span className="mt-1 max-w-full truncate text-[10px] font-black leading-none">
                {item.short}
              </span>
            </a>
          ))}
        </div>
      </nav>
    </div>
  );
}

export function OwnerCockpit({ data }: { data: OwnerCockpitData }) {
  const [selected, setSelected] = useState<string[]>(data.selectedListingIds);

  useEffect(() => {
    setSelected(data.selectedListingIds);
  }, [data.selectedListingIds]);

  if (data.listings.length === 0) {
    return (
      <main className="min-h-screen bg-[#F4F8FA] pb-28 text-[#112532] xl:pb-10">
        <TopNav notificationCount={0} />
        <div className="mx-auto max-w-3xl px-4 py-10">
          <ShellCard className="p-6">
            <h1 className="text-3xl font-black">Aucun logement lié</h1>
            <p className="mt-2 font-bold text-[#112532]/55">
              Ce lien propriétaire est actif, mais aucun bien n’est encore associé.
            </p>
          </ShellCard>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#F4F8FA] pb-28 text-[#112532] xl:pb-10">
      <TopNav notificationCount={data.timelineEvents.filter((event) => event.tone === "orange").length} />

      <div className="mx-auto w-full max-w-7xl space-y-5 px-4 py-5 sm:px-6 lg:px-8">
        <MoneyHero data={data} />
        <SmartBrief data={data} />
        <PropertySelector data={data} selected={selected} setSelected={setSelected} />
        <Planning data={data} selected={selected} />
        <OwnerPricingCalendar data={data} selectedListingIds={selected} />
        <OwnerJournalHeadlines data={data} />
      </div>

      <BottomNav />
    </main>
  );
}
