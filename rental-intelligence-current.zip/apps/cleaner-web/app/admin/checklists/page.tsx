import Link from "next/link";
import { requireAdmin } from "@/lib/adminAuth";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";
import {
  addChecklistSection,
  archiveChecklistSection,
  archiveSimpleChecklist,
  createNewChecklistVersion,
  createSimpleChecklist,
  updateChecklistSection,
  updateSimpleChecklist,
} from "./actions";

export const dynamic = "force-dynamic";

type Row = Record<string, any>;
type ChecklistTranslationLanguage = "en" | "ru";

function sectionTranslation(section: Row, language: ChecklistTranslationLanguage): Row {
  return section.translations?.[language] ?? {};
}

function selectedClass(isSelected: boolean): string {
  return isSelected
    ? "bg-[#112532] text-white"
    : "bg-slate-100 text-[#112532]/76";
}

function photoRequirementLabel(value?: string): string {
  if (value === "required") return "Photo obligatoire";
  if (value === "optional") return "Photo optionnelle";
  return "Pas de photo";
}

function serviceLabel(value?: string): string {
  switch (value) {
    case "garden_lawn":
      return "Jardin / tonte";
    case "deep_cleaning":
      return "Grand ménage";
    case "linen_laundry":
      return "Linge / lessive";
    case "inventory_check":
      return "Contrôle inventaire";
    case "maintenance_check":
      return "Petite maintenance";
    case "other":
      return "Mission ponctuelle";
    default:
      return "Ménage standard";
  }
}

function checklistUrl(propertyId: string, checklistId?: string): string {
  const params = new URLSearchParams();
  params.set("property", propertyId);
  if (checklistId) params.set("checklist", checklistId);
  return `/admin/checklists?${params.toString()}`;
}

function durationLabel(profile: Row): string {
  const hours = Number(profile.estimated_hours ?? 0);
  if (!hours) return "durée non définie";
  if (hours < 1) return `${Math.round(hours * 60)} min`;
  return `${String(hours).replace(".", ",")} h`;
}

function ChecklistCard({
  profile,
  selectedPropertyId,
  isSelected,
}: {
  profile: Row;
  selectedPropertyId: string;
  isSelected: boolean;
}) {
  return (
    <Link
      href={checklistUrl(selectedPropertyId, profile.id)}
      className={`block rounded-[1.25rem] p-4 shadow-sm ring-1 transition hover:-translate-y-0.5 hover:shadow-md ${
        isSelected
          ? "bg-[#112532] text-white ring-slate-950"
          : "bg-white text-[#112532] ring-[#112532]/10"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-black">{profile.label ?? profile.code}</h3>
          <p className={`mt-1 text-xs font-semibold ${isSelected ? "text-white/60" : "text-[#112532]/48"}`}>
            {serviceLabel(profile.service_type)} · {durationLabel(profile)}
          </p>
        </div>

        <span
          className={`rounded-full px-2 py-1 text-[10px] font-black ${
            profile.active === false
              ? "bg-red-100 text-red-800"
              : isSelected
                ? "bg-white/15 text-white"
                : "bg-emerald-100 text-emerald-800"
          }`}
        >
          {profile.active === false ? "Inactive" : "Active"}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {profile.default_linen_required && (
          <span className={`rounded-full px-2 py-1 text-[10px] font-black ${isSelected ? "bg-white/10 text-white/80" : "bg-slate-100 text-[#112532]/62"}`}>
            Linge
          </span>
        )}
        {profile.default_laundry_required && (
          <span className={`rounded-full px-2 py-1 text-[10px] font-black ${isSelected ? "bg-white/10 text-white/80" : "bg-slate-100 text-[#112532]/62"}`}>
            Lessive
          </span>
        )}
        <span className={`rounded-full px-2 py-1 text-[10px] font-black ${isSelected ? "bg-white/10 text-white/80" : "bg-slate-100 text-[#112532]/62"}`}>
          Ordre {profile.sort_order ?? 100}
        </span>
      </div>

      <p className={`mt-4 text-xs font-black ${isSelected ? "text-white/50" : "text-[#112532]/36"}`}>
        {isSelected ? "Sélectionnée" : "Modifier →"}
      </p>
    </Link>
  );
}

function SectionForm({ section }: { section: Row }) {
  return (
    <form
      key={section.id}
      action={updateChecklistSection}
      className={`rounded-[1.25rem] p-4 shadow-sm ring-1 ${
        section.active === false
          ? "bg-[#F6F3EF] opacity-70 ring-[#112532]/10"
          : "bg-white ring-[#112532]/10"
      }`}
    >
      <input type="hidden" name="id" value={section.id} />

      <div className="flex flex-wrap gap-2">
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black text-[#112532]/62">
          Clé stable : {section.section_key}
        </span>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black text-[#112532]/62">
          Ordre {section.sort_order ?? 100}
        </span>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black text-[#112532]/62">
          {photoRequirementLabel(section.photo_requirement)}
        </span>
        {section.required ? (
          <span className="rounded-full bg-emerald-100 px-2 py-1 text-[10px] font-black text-emerald-800">
            Obligatoire
          </span>
        ) : (
          <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black text-[#112532]/62">
            Optionnelle
          </span>
        )}
        {section.active === false && (
          <span className="rounded-full bg-red-100 px-2 py-1 text-[10px] font-black text-red-800">
            Masquée
          </span>
        )}
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <label className="block">
          <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
            Section
          </span>
          <input
            name="title"
            defaultValue={section.title ?? ""}
            className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
          />
        </label>

        <label className="block">
          <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
            Case principale à cocher
          </span>
          <input
            name="high_level_check_label"
            defaultValue={section.high_level_check_label ?? ""}
            className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
          />
        </label>

        <label className="block">
          <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
            Ordre
          </span>
          <input
            name="sort_order"
            type="number"
            defaultValue={section.sort_order ?? 100}
            className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
          />
        </label>

        <label className="block">
          <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
            Photos pour cette section
          </span>
          <select
            name="photo_requirement"
            defaultValue={section.photo_requirement ?? "none"}
            className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
          >
            <option value="none">Pas de photo</option>
            <option value="optional">Photo optionnelle</option>
            <option value="required">Photo obligatoire</option>
          </select>
        </label>
      </div>

      <label className="mt-3 block">
        <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
          Tâches / points de contrôle
        </span>
        <textarea
          name="detail_items"
          rows={5}
          defaultValue={(section.detail_items ?? []).join("\n")}
          placeholder="Un point par ligne"
          className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-3 text-sm font-semibold text-[#112532]"
        />
      </label>

      <details className="mt-3 rounded-2xl bg-[#F6F3EF] p-3 ring-1 ring-slate-100">
        <summary className="cursor-pointer text-xs font-black uppercase tracking-wide text-[#112532]/48">
          Traductions intervenantes EN / RU
        </summary>

        <p className="mt-2 text-xs font-semibold text-[#112532]/48">
          Le français reste la version canonique. Si une traduction est vide, l’app utilisera le texte français.
        </p>

        <div className="mt-3 grid gap-3 lg:grid-cols-2">
          {(["en", "ru"] as const).map((language) => {
            const translation = sectionTranslation(section, language);
            const label = language === "en" ? "Anglais" : "Russe";

            return (
              <div key={language} className="rounded-2xl bg-white p-3 ring-1 ring-[#112532]/10">
                <h4 className="text-sm font-black text-[#112532]">{label}</h4>

                <label className="mt-3 block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Section
                  </span>
                  <input
                    name={`${language}_title`}
                    defaultValue={translation.title ?? ""}
                    placeholder={section.title ?? ""}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
                  />
                </label>

                <label className="mt-3 block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Case principale
                  </span>
                  <input
                    name={`${language}_high_level_check_label`}
                    defaultValue={translation.high_level_check_label ?? ""}
                    placeholder={section.high_level_check_label ?? ""}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold text-[#112532]"
                  />
                </label>

                <label className="mt-3 block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Tâches traduites
                  </span>
                  <textarea
                    name={`${language}_detail_items`}
                    rows={5}
                    defaultValue={(translation.detail_items ?? []).join("\n")}
                    placeholder={(section.detail_items ?? []).join("\n")}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-3 text-sm font-semibold text-[#112532]"
                  />
                </label>
              </div>
            );
          })}
        </div>
      </details>

      <div className="mt-3 grid gap-2 md:grid-cols-3">
        <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
          <input type="checkbox" name="required" defaultChecked={section.required !== false} />
          Obligatoire
        </label>

        <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
          <input
            type="checkbox"
            name="visible_to_cleaner"
            defaultChecked={section.visible_to_cleaner !== false}
          />
          Visible intervenante
        </label>

        <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
          <input type="checkbox" name="active" defaultChecked={section.active !== false} />
          Active
        </label>
      </div>

      <p className="mt-4 rounded-2xl bg-[#FFF5DD] p-3 text-xs font-semibold text-amber-950 ring-1 ring-amber-100">
        Ces champs modifient cette version. À utiliser pour une faute, une clarification ou une traduction.
        Pour ajouter du travail ou changer le niveau d’exigence, créez une nouvelle version.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="submit"
          className="flex-1 rounded-full bg-[#112532] px-4 py-2 text-sm font-black text-white"
        >
          Corriger cette version
        </button>

        {section.active !== false && (
          <button
            formAction={archiveChecklistSection}
            className="rounded-full bg-red-50 px-4 py-2 text-sm font-black text-red-800 ring-1 ring-red-100"
          >
            Masquer cette section
          </button>
        )}
      </div>
    </form>
  );
}

export default async function AdminChecklistsPage({
  searchParams,
}: {
  searchParams?: Promise<{ property?: string; checklist?: string }>;
}) {
  await requireAdmin();

  const params = await searchParams;
  const supabase = getSupabaseAdmin();

  const { data: propertiesData, error: propertiesError } = await supabase
    .from("properties")
    .select("*")
    .order("name", { ascending: true });

  if (propertiesError) {
    throw new Error(`Impossible de charger les logements : ${propertiesError.message}`);
  }

  const properties = propertiesData ?? [];
  const selectedPropertyId = params?.property ?? properties[0]?.id ?? "";

  const { data: profilesData, error: profilesError } = selectedPropertyId
    ? await supabase
        .from("property_cleaning_profiles")
        .select("*")
        .eq("property_id", selectedPropertyId)
        .order("active", { ascending: false })
        .order("sort_order", { ascending: true })
        .order("label", { ascending: true })
    : { data: [], error: null };

  if (profilesError) {
    throw new Error(`Impossible de charger les checklists : ${profilesError.message}`);
  }

  const profiles = profilesData ?? [];
  const selectedProfileId =
    params?.checklist ??
    profiles.find((profile) => profile.active !== false)?.id ??
    profiles[0]?.id ??
    "";

  const selectedProfile = profiles.find((profile) => profile.id === selectedProfileId) ?? null;

  const { data: templatesData, error: templatesError } = selectedProfileId
    ? await supabase
        .from("cleaning_checklist_templates")
        .select("*")
        .eq("property_id", selectedPropertyId)
        .eq("cleaning_profile_id", selectedProfileId)
        .order("active", { ascending: false })
        .order("created_at", { ascending: false })
    : { data: [], error: null };

  if (templatesError) {
    throw new Error(`Impossible de charger le contenu de checklist : ${templatesError.message}`);
  }

  const templates = templatesData ?? [];
  const activeTemplate =
    templates.find((template) => template.active !== false) ?? templates[0] ?? null;

  const { data: sectionsData, error: sectionsError } = activeTemplate
    ? await supabase
        .from("cleaning_checklist_sections")
        .select("*")
        .eq("template_id", activeTemplate.id)
        .order("sort_order", { ascending: true })
    : { data: [], error: null };

  if (sectionsError) {
    throw new Error(`Impossible de charger les sections : ${sectionsError.message}`);
  }

  const sectionRows = sectionsData ?? [];
  const sectionIds = sectionRows
    .map((section) => section.id)
    .filter((id): id is string => typeof id === "string" && id.length > 0);

  const { data: sectionTranslationsData, error: sectionTranslationsError } = sectionIds.length > 0
    ? await supabase
        .from("cleaning_checklist_section_translations")
        .select("section_id,language,title,high_level_check_label,detail_items")
        .in("section_id", sectionIds)
    : { data: [], error: null };

  if (sectionTranslationsError) {
    throw new Error(`Impossible de charger les traductions : ${sectionTranslationsError.message}`);
  }

  const translationsBySectionId = new Map<string, Record<ChecklistTranslationLanguage, Row>>();

  for (const translation of sectionTranslationsData ?? []) {
    const language = translation.language as ChecklistTranslationLanguage;
    if (language !== "en" && language !== "ru") continue;

    const current = translationsBySectionId.get(translation.section_id) ?? { en: {}, ru: {} };
    current[language] = translation;
    translationsBySectionId.set(translation.section_id, current);
  }

  const sections = sectionRows.map((section) => ({
    ...section,
    translations: translationsBySectionId.get(section.id) ?? { en: {}, ru: {} },
  }));

  const selectedProperty = properties.find((property) => property.id === selectedPropertyId);

  const { count: activeTemplateUsageCount } = activeTemplate
    ? await supabase
        .from("cleaning_requests")
        .select("id", { count: "exact", head: true })
        .eq("checklist_template_id", activeTemplate.id)
    : { count: 0 };

  return (
    <main className="min-h-screen bg-[#F6F3EF] px-3 py-4 text-[#112532] sm:px-6">
      <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/80 px-3 py-2 text-[10px] font-black uppercase tracking-[0.18em] text-[#112532]/45 ring-1 ring-[#112532]/8"><span className="h-2 w-2 rounded-full bg-[#E0680E]" />Pilotys · opération</div>
        <div className="mx-auto max-w-6xl space-y-5">
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <Link href="/admin/settings" className="text-sm font-semibold text-[#112532]/48">
              ← Back office
            </Link>

            <h1 className="mt-4 text-3xl font-black tracking-tight">
              Checklists par logement
            </h1>

            <p className="mt-1 max-w-2xl text-sm font-semibold text-[#112532]/48">
              Chaque logement peut avoir plusieurs checklists : ménage léger, ménage standard,
              grand ménage, jardinage, petite maintenance ou mission ponctuelle.
            </p>
          </div>

          <Link
            href="/admin/photos"
            className="rounded-full bg-white px-3 py-2 text-xs font-black text-[#112532]/76 shadow-sm ring-1 ring-[#112532]/10"
          >
            Photos
          </Link>
        </header>

        <section className="rounded-[1.25rem] bg-white p-4 shadow-sm ring-1 ring-[#112532]/10">
          <p className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
            Logement
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            {properties.map((property) => (
              <Link
                key={property.id}
                href={checklistUrl(property.id)}
                className={`rounded-full px-3 py-2 text-xs font-black ${selectedClass(
                  property.id === selectedPropertyId,
                )}`}
              >
                {property.name}
              </Link>
            ))}
          </div>
        </section>

        {selectedPropertyId && (
          <section className="rounded-[1.25rem] bg-white p-4 shadow-sm ring-1 ring-[#112532]/10">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                  Checklists disponibles
                </p>
                <h2 className="text-xl font-black text-[#112532]">
                  {selectedProperty?.name ?? "Logement"}
                </h2>
              </div>

              <details className="w-full rounded-2xl bg-[#F6F3EF] p-3 ring-1 ring-slate-100 md:w-auto md:min-w-[360px]">
                <summary className="cursor-pointer text-sm font-black text-[#112532]">
                  + Créer une checklist
                </summary>

                <form action={createSimpleChecklist} className="mt-3 grid gap-3">
                  <input type="hidden" name="property_id" value={selectedPropertyId} />

                  <label className="block">
                    <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                      Nom
                    </span>
                    <input
                      name="label"
                      placeholder="Ex : Ménage léger, Jardinage, Réparer poignée"
                      className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-white px-3 py-2 text-sm font-bold"
                    />
                  </label>

                  <div className="grid gap-2 md:grid-cols-2">
                    <label className="block">
                      <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                        Code interne
                      </span>
                      <input
                        name="code"
                        placeholder="menage_leger"
                        className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-white px-3 py-2 text-sm font-bold"
                      />
                    </label>

                    <label className="block">
                      <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                        Durée estimée
                      </span>
                      <input
                        name="estimated_hours"
                        defaultValue="2"
                        className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-white px-3 py-2 text-sm font-bold"
                      />
                    </label>
                  </div>

                  <label className="block">
                    <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                      Catégorie
                    </span>
                    <select
                      name="service_type"
                      defaultValue="standard_cleaning"
                      className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-white px-3 py-2 text-sm font-bold"
                    >
                      <option value="standard_cleaning">Ménage standard</option>
                      <option value="deep_cleaning">Grand ménage</option>
                      <option value="garden_lawn">Jardin / tonte</option>
                      <option value="linen_laundry">Linge / lessive</option>
                      <option value="inventory_check">Contrôle inventaire</option>
                      <option value="maintenance_check">Petite maintenance</option>
                      <option value="other">Mission ponctuelle</option>
                    </select>
                  </label>

                  <input type="hidden" name="sort_order" value="100" />

                  <div className="grid gap-2 md:grid-cols-3">
                    <label className="flex items-center gap-2 rounded-2xl bg-white p-3 text-xs font-bold text-[#112532]/76">
                      <input type="checkbox" name="default_linen_required" defaultChecked />
                      Linge
                    </label>
                    <label className="flex items-center gap-2 rounded-2xl bg-white p-3 text-xs font-bold text-[#112532]/76">
                      <input type="checkbox" name="default_laundry_required" defaultChecked />
                      Lessive
                    </label>
                    <label className="flex items-center gap-2 rounded-2xl bg-white p-3 text-xs font-bold text-[#112532]/76">
                      <input type="checkbox" name="use_master" defaultChecked />
                      Préremplir avec le master
                    </label>
                  </div>

                  <button className="rounded-full bg-[#112532] px-4 py-2 text-sm font-black text-white">
                    Créer
                  </button>
                </form>
              </details>
            </div>

            {profiles.length === 0 ? (
              <div className="mt-4 rounded-2xl bg-[#FFF5DD] p-4 text-sm font-semibold text-amber-900 ring-1 ring-amber-100">
                Aucune checklist pour ce logement. Créez la première, idéalement avec le master.
              </div>
            ) : (
              <div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {profiles.map((profile) => (
                  <ChecklistCard
                    key={profile.id}
                    profile={profile}
                    selectedPropertyId={selectedPropertyId}
                    isSelected={profile.id === selectedProfileId}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {selectedProfile && activeTemplate && (
          <section className="rounded-[1.25rem] bg-white p-4 shadow-sm ring-1 ring-[#112532]/10">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                  Checklist sélectionnée
                </p>
                <h2 className="text-xl font-black text-[#112532]">
                  {selectedProfile.label}
                </h2>
              </div>

              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-[#112532]/62">
                {sections.length} section(s)
              </span>
            </div>

            <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_auto]">
              <div className="rounded-2xl bg-[#FFF5DD] p-4 text-sm font-semibold text-amber-950 ring-1 ring-amber-100">
                <p className="font-black">
                  Version {activeTemplate.version ?? "—"} · utilisée par {activeTemplateUsageCount ?? 0} mission(s)
                </p>
                <p className="mt-1">
                  Petite correction : modifiez cette version. Cela peut affecter les missions déjà envoyées avec cette version.
                </p>
                <p className="mt-1">
                  Changement de contenu, durée, photo obligatoire ou niveau de prestation : créez une nouvelle version.
                  Les nouvelles missions utiliseront la nouvelle version, les anciennes gardent l’ancienne.
                </p>
              </div>

              <form action={createNewChecklistVersion} className="flex items-stretch">
                <input type="hidden" name="source_template_id" value={activeTemplate.id} />
                <button className="w-full rounded-2xl bg-[#112532] px-5 py-3 text-sm font-black text-white shadow-sm lg:w-auto">
                  Créer une nouvelle version
                </button>
              </form>
            </div>

            <form action={updateSimpleChecklist} className="mt-4 space-y-3">
              <input type="hidden" name="profile_id" value={selectedProfile.id} />
              <input type="hidden" name="template_id" value={activeTemplate.id} />

              <div className="grid gap-3 md:grid-cols-2">
                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Nom
                  </span>
                  <input
                    name="label"
                    defaultValue={selectedProfile.label ?? ""}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Code interne
                  </span>
                  <input
                    name="code"
                    defaultValue={selectedProfile.code ?? ""}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Catégorie
                  </span>
                  <select
                    name="service_type"
                    defaultValue={selectedProfile.service_type ?? "standard_cleaning"}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  >
                    <option value="standard_cleaning">Ménage standard</option>
                    <option value="deep_cleaning">Grand ménage</option>
                    <option value="garden_lawn">Jardin / tonte</option>
                    <option value="linen_laundry">Linge / lessive</option>
                    <option value="inventory_check">Contrôle inventaire</option>
                    <option value="maintenance_check">Petite maintenance</option>
                    <option value="other">Mission ponctuelle</option>
                  </select>
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Durée estimée
                  </span>
                  <input
                    name="estimated_hours"
                    defaultValue={selectedProfile.estimated_hours ?? 2}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Ordre
                  </span>
                  <input
                    name="sort_order"
                    type="number"
                    defaultValue={selectedProfile.sort_order ?? 100}
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>
              </div>

              <div className="grid gap-2 md:grid-cols-3">
                <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
                  <input
                    type="checkbox"
                    name="default_linen_required"
                    defaultChecked={selectedProfile.default_linen_required === true}
                  />
                  Linge par défaut
                </label>

                <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
                  <input
                    type="checkbox"
                    name="default_laundry_required"
                    defaultChecked={selectedProfile.default_laundry_required === true}
                  />
                  Lessive par défaut
                </label>

                <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
                  <input
                    type="checkbox"
                    name="active"
                    defaultChecked={selectedProfile.active !== false}
                  />
                  Active
                </label>
              </div>

              <div className="flex flex-wrap gap-2">
                <button className="flex-1 rounded-full bg-[#112532] px-4 py-2 text-sm font-black text-white">
                  Corriger cette version
                </button>

                <button
                  formAction={archiveSimpleChecklist}
                  className="rounded-full bg-red-50 px-4 py-2 text-sm font-black text-red-800 ring-1 ring-red-100"
                >
                  Archiver / désactiver
                </button>
              </div>
            </form>
          </section>
        )}

        {selectedProfile && !activeTemplate && (
          <section className="rounded-[1.25rem] bg-white p-5 text-center shadow-sm ring-1 ring-[#112532]/10">
            <h2 className="text-xl font-black text-[#112532]">
              Checklist sans contenu
            </h2>
            <p className="mt-1 text-sm font-semibold text-[#112532]/48">
              Cette checklist existe, mais aucun contenu n’est attaché. Créez une nouvelle checklist avec le master ou ajoutez les sections manuellement.
            </p>
          </section>
        )}

        {activeTemplate && (
          <section className="rounded-[1.25rem] bg-white p-4 shadow-sm ring-1 ring-[#112532]/10">
            <h2 className="text-xl font-black text-[#112532]">
              Ajouter une section
            </h2>

            <p className="mt-2 rounded-2xl bg-[#FFF5DD] p-3 text-sm font-semibold text-amber-950 ring-1 ring-amber-100">
              Ajouter une section augmente le travail demandé. Si cela ne doit s’appliquer qu’aux nouvelles missions,
              créez d’abord une nouvelle version.
            </p>

            <form action={addChecklistSection} className="mt-4 space-y-3">
              <input type="hidden" name="template_id" value={activeTemplate.id} />

              <div className="grid gap-3 md:grid-cols-2">
                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Section
                  </span>
                  <input
                    name="title"
                    placeholder="Ex : Terrasse"
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Case principale à cocher
                  </span>
                  <input
                    name="high_level_check_label"
                    placeholder="Ex : Terrasse propre et rangée"
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Ordre
                  </span>
                  <input
                    name="sort_order"
                    type="number"
                    defaultValue="100"
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  />
                </label>

                <label className="block">
                  <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                    Photos pour cette section
                  </span>
                  <select
                    name="photo_requirement"
                    defaultValue="none"
                    className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-2 text-sm font-bold"
                  >
                    <option value="none">Pas de photo</option>
                    <option value="optional">Photo optionnelle</option>
                    <option value="required">Photo obligatoire</option>
                  </select>
                </label>
              </div>

              <label className="block">
                <span className="text-[10px] font-black uppercase tracking-wide text-[#112532]/36">
                  Tâches / points de contrôle
                </span>
                <textarea
                  name="detail_items"
                  rows={5}
                  placeholder={"Un point par ligne\nEx : Table propre\nEx : Chaises rangées"}
                  className="mt-1 w-full rounded-2xl border border-[#112532]/10 bg-[#F6F3EF] px-3 py-3 text-sm font-semibold"
                />
              </label>

              <div className="grid gap-2 md:grid-cols-2">
                <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
                  <input type="checkbox" name="required" defaultChecked />
                  Section obligatoire
                </label>

                <label className="flex items-center gap-2 rounded-2xl bg-[#F6F3EF] p-3 text-sm font-semibold text-[#112532]/76">
                  <input type="checkbox" name="visible_to_cleaner" defaultChecked />
                  Visible intervenante
                </label>
              </div>

              <button className="w-full rounded-full bg-[#112532] px-4 py-2 text-sm font-black text-white">
                Ajouter la section
              </button>
            </form>
          </section>
        )}

        {activeTemplate && (
          <section className="space-y-3">
            <div>
              <h2 className="text-2xl font-black text-[#112532]">
                Sections de la checklist
              </h2>
              <p className="mt-1 text-sm font-semibold text-[#112532]/48">
                {sections.length} section(s). Les photos restent liées à la section via le réglage “photo obligatoire/optionnelle”.
              </p>
            </div>

            {sections.length === 0 ? (
              <div className="rounded-[1.25rem] bg-white p-5 text-sm font-semibold text-[#112532]/48 shadow-sm ring-1 ring-[#112532]/10">
                Aucune section pour l’instant.
              </div>
            ) : (
              sections.map((section) => <SectionForm key={section.id} section={section} />)
            )}
          </section>
        )}
      </div>
    </main>
  );
}
